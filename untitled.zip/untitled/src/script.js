

// JavaScript para adicionar funcionalidades no futuro, como animações ou interação com o usuário.

// Neste momento, o arquivo está vazio, mas pode ser usado para efeitos adicionais, como

// animações de rolagem, alertas ou até mesmo integrar um sistema de pedidos.

console.log("Bem-vindo à Pizzaria Delícia!");

